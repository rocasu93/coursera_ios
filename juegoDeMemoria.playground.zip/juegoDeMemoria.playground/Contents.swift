//: Playground - noun: a place where people can play

import UIKit
var rango =  30...40
var num = 0...100
for i in num{
    var div5 = (i % 5)
    if(div5 == 0){
        print("#\(i)","Bingo!")
    }
    var div2 = (i % 2)
    if(div2 == 0){
        print("#\(i)","par!")
    }else{
        print("#\(i)","impar!")
    }
    if(rango.contains(i)){
        print("#\(i)","Viva Swift!")

    }
}